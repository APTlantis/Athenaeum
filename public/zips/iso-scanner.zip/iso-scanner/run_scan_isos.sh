#!/bin/bash
# =========================================================
# Script Name: run_iso_scanner_copier.sh
# Description: Alternative shell script wrapper for the ISO Scanner and Copier tool
# Author: APTlantis Team
# Creation Date: 2025-05-16
# Last Modified: 2025-05-18
# 
# Dependencies:
# - iso_scanner_copier (Go binary)
# 
# Usage:
#   ./run_iso_scanner_copier.sh [options]
# 
# Options:
#   -s, --source DIR     Source directory
#   -d, --dest DIR       Destination directory
#   -w, --workers NUM    Number of parallel workers
#   -b, --bwlimit LIMIT  Bandwidth limit (e.g., '50M')
#   -n, --dry-run        Dry run (don't actually copy files)
#   -h, --help           Show this help message
# =========================================================

# Script to run the ISO Scanner and Copier tool with common options

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Default values
SOURCE="/mnt/aptlantis/mirrors/"
DEST="/mnt/aptlanti/isos/"
WORKERS=4
BWLIMIT=""
DRY_RUN=false

# Display help
function show_help {
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  -s, --source DIR     Source directory (default: $SOURCE)"
    echo "  -d, --dest DIR       Destination directory (default: $DEST)"
    echo "  -w, --workers NUM    Number of parallel workers (default: $WORKERS)"
    echo "  -b, --bwlimit LIMIT  Bandwidth limit (e.g., '50M')"
    echo "  -n, --dry-run        Dry run (don't actually copy files)"
    echo "  -h, --help           Show this help message"
    echo ""
    echo "Example:"
    echo "  $0 --bwlimit 50M --workers 8"
    exit 0
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        -s|--source)
            SOURCE="$2"
            shift 2
            ;;
        -d|--dest)
            DEST="$2"
            shift 2
            ;;
        -w|--workers)
            WORKERS="$2"
            shift 2
            ;;
        -b|--bwlimit)
            BWLIMIT="$2"
            shift 2
            ;;
        -n|--dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            show_help
            ;;
        *)
            echo "Unknown option: $1"
            show_help
            ;;
    esac
done

# Build the command
CMD="./iso_scanner_copier -source=\"$SOURCE\" -dest=\"$DEST\" -workers=$WORKERS"

if [ -n "$BWLIMIT" ]; then
    CMD="$CMD -bwlimit=\"$BWLIMIT\""
fi

if [ "$DRY_RUN" = true ]; then
    CMD="$CMD -dry-run"
fi

# Print the command
echo "Running command: $CMD"

# Execute the command
eval $CMD
