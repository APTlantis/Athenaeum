# ISO Scanner

This tool recursively scans a source directory for ISO files and their checksums, and copies them to a destination directory. It's designed to handle large volumes of data efficiently.

## Features

- Recursively scans directories for ISO files
- Optionally includes checksum files (.md5, .sha1, .sha256, etc.)
- Calculates MD5 checksums for verification
- Uses rsync for efficient copying
- Parallel processing with multiple worker threads
- Bandwidth limiting options
- Dry-run capability for testing

## Usage

### Direct Execution

```bash
./scan_isos [options]
```

### Using the Shell Script Wrapper

For convenience, you can also use the provided shell script:

```bash
./scan_isos.sh [options]
```

Or the alternative wrapper:

```bash
./run_scan_isos.sh [options]
```

The shell script provides a more user-friendly interface with both short and long option formats:

```
Options:
  -s, --source DIR     Source directory
  -d, --dest DIR       Destination directory
  -w, --workers NUM    Number of parallel workers
  -b, --bwlimit LIMIT  Bandwidth limit (e.g., '50M')
  -n, --dry-run        Dry run (don't actually copy files)
  -h, --help           Show this help message
```

## Options

- `-source string`: Source directory to scan (default "/mnt/aptlantis/mirrors/")
- `-dest string`: Destination directory for copies (default "/mnt/aptlanti/isos/")
- `-workers int`: Number of parallel copy workers (default 4)
- `-verbose`: Verbose output (default true)
- `-dry-run`: Dry run (don't actually copy) (default false)
- `-only-isos`: Only process .iso files (default true)
- `-include-checksums`: Also copy checksum files (.md5, .sha256, etc.) (default true)
- `-bwlimit string`: Bandwidth limit (e.g., '10M' for 10MB/s)

## Examples

### Basic Usage

```bash
./scan_isos
```

This will scan `/mnt/aptlantis/mirrors/` for ISO files and checksums, and copy them to `/mnt/aptlanti/isos/`.

### Custom Source and Destination

```bash
./scan_isos -source="/path/to/source" -dest="/path/to/destination"
```

### Limit Bandwidth

```bash
./scan_isos -bwlimit="50M"
```

This limits the bandwidth to 50MB/s.

### Dry Run

```bash
./scan_isos -dry-run
```

This will scan files but not actually copy them.

### Increase Workers for Faster Copying

```bash
./scan_isos -workers=8
```

This increases the number of parallel copy operations to 8.

## Handling Large Data Volumes

This tool is designed to handle large data volumes (80TB+) efficiently:

1. It uses parallel workers to process multiple files simultaneously
2. It uses rsync for efficient copying, which:
   - Only copies files that don't exist or have changed
   - Supports resuming interrupted transfers
   - Has built-in bandwidth control
3. It creates a structured directory hierarchy in the destination that mirrors the source

### Recommended Approach for Large Data Sets

When dealing with very large data sets (like 80TB), it's recommended to:

1. **Start with a dry run** to see what would be copied without actually copying:
   ```bash
   ./run_scan_isos.sh --dry-run
   ```

2. **Run with bandwidth limits** to avoid network congestion:
   ```bash
   ./run_scan_isos.sh --bwlimit 100M
   ```

3. **Adjust worker count** based on your system's capabilities:
   - For systems with many CPU cores and good I/O: `--workers 8` or higher
   - For systems with limited resources: `--workers 2` to reduce load

4. **Run in the background** for long-running operations:
   ```bash
   nohup ./run_scan_isos.sh --bwlimit 100M > iso_copy.log 2>&1 &
   ```
   This will run the process in the background, saving all output to `iso_copy.log`

## Requirements

- Go 1.13 or higher
- rsync must be installed on the system
