// =========================================================
// Script Name: iso_scanner_copier.go
// Description: Scans directories for ISO files and copies them to a destination with optional checksums
// Author: APTlantis Team
// Creation Date: 2025-05-16
// Last Modified: 2025-05-18
//
// Dependencies:
// - None (standard library only)
//
// Usage:
//   go run iso_scanner_copier.go [options]
//
// Options:
//   -source string    Source directory to scan (default "/mnt/aptlantis/mirror/")
//   -dest string      Destination directory for copies (default "/mnt/aptlanti/isos/")
//   -workers int      Number of parallel copy workers (default 4)
//   -verbose          Verbose output (default true)
//   -dry-run          Dry run (don't actually copy)
//   -only-isos        Only process .iso files (default true)
//   -checksums        Include MD5 checksums (default false)
//   -bwlimit string   Bandwidth limit (e.g. "10M")
// =========================================================

package main

import (
	"crypto/md5"
	"encoding/hex"
	"flag"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// FileInfo represents information about a file
type FileInfo struct {
	Path      string `json:"path"`
	Size      int64  `json:"size"`
	MD5Hash   string `json:"md5_hash"`
	SourceDir string `json:"source_dir"`
}

// Configuration options
type Config struct {
	SourceDir        string
	DestDir          string
	Workers          int
	Verbose          bool
	DryRun           bool
	OnlyISOs         bool
	IncludeChecksums bool
	BwLimit          string
}

func main() {
	// Parse command line arguments
	config := parseFlags()

	// Validate configuration
	if err := validateConfig(config); err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}

	// Print configuration summary
	if config.Verbose {
		printConfig(config)
	}

	// Create channels for communication
	filesChan := make(chan FileInfo, 1000)
	resultsChan := make(chan bool, 1000)

	// Create wait groups
	var scanWg sync.WaitGroup
	var copyWg sync.WaitGroup

	// Start scanner goroutine
	scanWg.Add(1)
	go scanDirectories(config, filesChan, &scanWg)

	// Start worker goroutines for copying
	for i := 0; i < config.Workers; i++ {
		copyWg.Add(1)
		go copyWorker(i, config, filesChan, resultsChan, &copyWg)
	}

	// Wait for scanning to complete
	go func() {
		scanWg.Wait()
		close(filesChan)
	}()

	// Wait for copying to complete
	go func() {
		copyWg.Wait()
		close(resultsChan)
	}()

	// Count successful and failed transfers
	successCount := 0
	failCount := 0
	for result := range resultsChan {
		if result {
			successCount++
		} else {
			failCount++
		}
	}

	// Print summary
	fmt.Printf("\nTransfer Summary:\n")
	fmt.Printf("  Successfully copied: %d files\n", successCount)
	if failCount > 0 {
		fmt.Printf("  Failed to copy: %d files\n", failCount)
	}
	fmt.Println("Operation completed!")
}

// Parse command line flags
func parseFlags() *Config {
	config := &Config{}

	flag.StringVar(&config.SourceDir, "source", "/mnt/aptlantis/mirror/", "Source directory to scan")
	flag.StringVar(&config.DestDir, "dest", "/mnt/aptlanti/isos/", "Destination directory for copies")
	flag.IntVar(&config.Workers, "workers", 4, "Number of parallel copy workers")
	flag.BoolVar(&config.Verbose, "verbose", true, "Verbose output")
	flag.BoolVar(&config.DryRun, "dry-run", false, "Dry run (don't actually copy)")
	flag.BoolVar(&config.OnlyISOs, "only-isos", true, "Only process .iso files")
	flag.BoolVar(&config.IncludeChecksums, "include-checksums", true, "Also copy checksum files (.md5, .sha256, etc.)")
	flag.StringVar(&config.BwLimit, "bwlimit", "", "Bandwidth limit (e.g., '10M' for 10MB/s)")

	flag.Parse()

	return config
}

// Validate the configuration
func validateConfig(config *Config) error {
	// Check if source directory exists
	if _, err := os.Stat(config.SourceDir); os.IsNotExist(err) {
		return fmt.Errorf("source directory does not exist: %s", config.SourceDir)
	}

	// Check if destination directory exists, create if not
	if _, err := os.Stat(config.DestDir); os.IsNotExist(err) {
		if err := os.MkdirAll(config.DestDir, 0755); err != nil {
			return fmt.Errorf("failed to create destination directory: %v", err)
		}
		fmt.Printf("Created destination directory: %s\n", config.DestDir)
	}

	// Ensure source directory ends with a slash
	if !strings.HasSuffix(config.SourceDir, string(os.PathSeparator)) {
		config.SourceDir += string(os.PathSeparator)
	}

	// Ensure destination directory ends with a slash
	if !strings.HasSuffix(config.DestDir, string(os.PathSeparator)) {
		config.DestDir += string(os.PathSeparator)
	}

	// Validate workers
	if config.Workers < 1 {
		return fmt.Errorf("number of workers must be at least 1")
	}

	return nil
}

// Print the configuration
func printConfig(config *Config) {
	fmt.Println("Configuration:")
	fmt.Printf("  Source Directory: %s\n", config.SourceDir)
	fmt.Printf("  Destination Directory: %s\n", config.DestDir)
	fmt.Printf("  Workers: %d\n", config.Workers)
	fmt.Printf("  Only ISOs: %v\n", config.OnlyISOs)
	fmt.Printf("  Include Checksums: %v\n", config.IncludeChecksums)
	if config.BwLimit != "" {
		fmt.Printf("  Bandwidth Limit: %s\n", config.BwLimit)
	}
	fmt.Printf("  Dry Run: %v\n", config.DryRun)
	fmt.Println()
}

// Scan directories recursively and send file info to the channel
func scanDirectories(config *Config, filesChan chan<- FileInfo, wg *sync.WaitGroup) {
	defer wg.Done()

	fmt.Printf("Scanning directory: %s\n", config.SourceDir)
	startTime := time.Now()
	fileCount := 0
	totalSize := int64(0)

	// Walk the source directory
	err := filepath.Walk(config.SourceDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error accessing path %s: %v\n", path, err)
			return nil // Continue walking despite the error
		}

		// Skip directories
		if info.IsDir() {
			return nil
		}

		// Check file extension
		ext := strings.ToLower(filepath.Ext(path))

		// Process ISO files
		if config.OnlyISOs && ext == ".iso" {
			fileCount++
			totalSize += info.Size()

			// Calculate MD5 hash if not in dry run mode
			var md5Hash string
			if !config.DryRun {
				var err error
				md5Hash, err = calculateMD5(path)
				if err != nil {
					fmt.Printf("Warning: Could not calculate MD5 for %s: %v\n", path, err)
				}
			}

			filesChan <- FileInfo{
				Path:      path,
				Size:      info.Size(),
				MD5Hash:   md5Hash,
				SourceDir: config.SourceDir,
			}

			if config.Verbose {
				fmt.Printf("Found ISO: %s (%s)\n", path, humanReadableSize(info.Size()))
			}
		}

		// Process checksum files if enabled
		if config.IncludeChecksums && isChecksumFile(ext) {
			fileCount++
			totalSize += info.Size()

			filesChan <- FileInfo{
				Path:      path,
				Size:      info.Size(),
				MD5Hash:   "", // No need to calculate MD5 for checksum files
				SourceDir: config.SourceDir,
			}

			if config.Verbose {
				fmt.Printf("Found checksum file: %s\n", path)
			}
		}

		return nil
	})

	if err != nil {
		fmt.Fprintf(os.Stderr, "Error scanning directory: %v\n", err)
	}

	duration := time.Since(startTime)
	fmt.Printf("\nScan completed in %v\n", duration)
	fmt.Printf("Found %d files totaling %s\n", fileCount, humanReadableSize(totalSize))
}

// Check if a file extension is a checksum file
func isChecksumFile(ext string) bool {
	checksumExts := []string{".md5", ".sha1", ".sha256", ".sha512", ".asc", ".sig"}
	for _, checksumExt := range checksumExts {
		if ext == checksumExt {
			return true
		}
	}
	return false
}

// Calculate MD5 hash of a file
func calculateMD5(filePath string) (string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer file.Close()

	hash := md5.New()
	if _, err := io.Copy(hash, file); err != nil {
		return "", err
	}

	return hex.EncodeToString(hash.Sum(nil)), nil
}

// Worker function to copy files
func copyWorker(id int, config *Config, filesChan <-chan FileInfo, resultsChan chan<- bool, wg *sync.WaitGroup) {
	defer wg.Done()

	for fileInfo := range filesChan {
		// Get the relative path from the source directory
		relPath, err := filepath.Rel(fileInfo.SourceDir, fileInfo.Path)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Worker %d: Error getting relative path: %v\n", id, err)
			resultsChan <- false
			continue
		}

		// Create destination path
		destPath := filepath.Join(config.DestDir, relPath)

		// Create destination directory if it doesn't exist
		destDir := filepath.Dir(destPath)
		if err := os.MkdirAll(destDir, 0755); err != nil {
			fmt.Fprintf(os.Stderr, "Worker %d: Error creating directory %s: %v\n", id, destDir, err)
			resultsChan <- false
			continue
		}

		// Skip if destination file already exists with same size
		if destFileInfo, err := os.Stat(destPath); err == nil {
			if destFileInfo.Size() == fileInfo.Size {
				fmt.Printf("Worker %d: File already exists with same size, skipping: %s\n", id, relPath)
				resultsChan <- true
				continue
			}
		}

		fmt.Printf("Worker %d: Copying %s (%s)\n", id, relPath, humanReadableSize(fileInfo.Size))

		// Skip actual copying in dry run mode
		if config.DryRun {
			fmt.Printf("Worker %d: [DRY RUN] Would copy: %s\n", id, relPath)
			resultsChan <- true
			continue
		}

		// Build rsync command for efficient copying
		args := buildRsyncArgs(fileInfo.Path, destPath, config)

		// Execute the rsync command
		startTime := time.Now()
		cmd := exec.Command("rsync", args...)
		cmd.Stdout = os.Stdout
		cmd.Stderr = os.Stderr

		if err := cmd.Run(); err != nil {
			fmt.Fprintf(os.Stderr, "Worker %d: Error copying %s: %v\n", id, relPath, err)
			resultsChan <- false
			continue
		}

		duration := time.Since(startTime)
		fmt.Printf("Worker %d: Successfully copied %s in %v\n", id, relPath, duration)
		resultsChan <- true
	}
}

// Build rsync command arguments
func buildRsyncArgs(sourcePath, destPath string, config *Config) []string {
	args := []string{}

	// Basic options
	args = append(args, "-a") // Archive mode
	args = append(args, "-h") // Human-readable numbers

	if config.Verbose {
		args = append(args, "-v") // Verbose
	}

	args = append(args, "--progress") // Show progress
	args = append(args, "--partial")  // Keep partially transferred files

	// Performance options
	if config.BwLimit != "" {
		args = append(args, fmt.Sprintf("--bwlimit=%s", config.BwLimit))
	}

	// Source and destination paths
	args = append(args, sourcePath, destPath)

	return args
}

// Convert bytes to human-readable size
func humanReadableSize(bytes int64) string {
	const unit = 1024
	if bytes < unit {
		return fmt.Sprintf("%d B", bytes)
	}
	div, exp := int64(unit), 0
	for n := bytes / unit; n >= unit; n /= unit {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %cB", float64(bytes)/float64(div), "KMGTPE"[exp])
}
