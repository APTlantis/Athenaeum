# APTlantis File Downloader

A lightweight, cross-platform file downloader application designed for humanitarian efforts to provide information to people in restrictive environments.

## Features

- Downloads a file list from aptlantis.net/files.txt
- Displays the file list to users with file sizes (if available)
- Allows selection of one or multiple files for download
- Shows download progress with speed and ETA
- Works across platforms (Windows, macOS, Linux, etc.)
- No external dependencies
- Small executable size
- Uses HTTPS for secure communication
- Stores file list in memory (no local file storage required)
- Handles network interruptions gracefully
- Creates a dedicated downloads folder

## Humanitarian Context

This application is designed for use in restrictive environments such as Iran, China, North Korea, and parts of Africa. Key considerations:

- **No external dependencies**: The application is completely self-contained and doesn't rely on external tools like wget.
- **Small footprint**: The compiled binary is as small as possible to facilitate distribution in bandwidth-constrained environments.
- **Cross-platform**: Works on a wide range of devices and operating systems, from modern iPads to Windows 7.
- **Secure communication**: Uses HTTPS to hide path, file content, and headers from surveillance.
- **Simple interface**: Easy to use even for users with limited technical experience.

## Building from Source

### Prerequisites

- Go 1.16 or higher

### Build Instructions

#### Unix/Linux/macOS (Bash)

```bash
# Clone the repository
git clone https://github.com/yourusername/aptlantis_downloader.git
cd aptlantis_downloader

# Build for your current platform
go build -ldflags="-s -w" -o aptlantis_downloader

# Cross-compile for Windows
GOOS=windows GOARCH=amd64 go build -ldflags="-s -w" -o aptlantis_downloader.exe

# Cross-compile for macOS
GOOS=darwin GOARCH=amd64 go build -ldflags="-s -w" -o aptlantis_downloader_mac

# Cross-compile for Linux
GOOS=linux GOARCH=amd64 go build -ldflags="-s -w" -o aptlantis_downloader_linux
```

#### Windows (PowerShell)

```powershell
# Clone the repository
git clone https://github.com/yourusername/aptlantis_downloader.git
cd aptlantis_downloader

# Build for your current platform
go build -ldflags="-s -w" -o aptlantis_downloader.exe

# Cross-compile for Windows
$env:GOOS = "windows"; $env:GOARCH = "amd64"; go build -ldflags="-s -w" -o aptlantis_downloader.exe

# Cross-compile for macOS
$env:GOOS = "darwin"; $env:GOARCH = "amd64"; go build -ldflags="-s -w" -o aptlantis_downloader_mac

# Cross-compile for Linux
$env:GOOS = "linux"; $env:GOARCH = "amd64"; go build -ldflags="-s -w" -o aptlantis_downloader_linux
```

The `-ldflags="-s -w"` flag reduces the binary size by removing debug information.

## Usage

1. Run the executable:
   ```
   ./aptlantis_downloader
   ```
   or on Windows:
   ```
   aptlantis_downloader.exe
   ```

2. The application will download the file list from aptlantis.net/files.txt.

3. Select files to download by entering their numbers (comma-separated), "all" for all files, or "q" to quit:
   ```
   Enter the numbers of the files you want to download (comma-separated)
   Example: 1,3,5 or 'all' for all files, or 'q' to quit:
   > 1,3
   ```

4. The selected files will be downloaded to the current directory with progress reporting.

## Security Considerations

- The application accepts any TLS certificate to work in environments where HTTPS might be intercepted.
- No data is stored on disk except for the downloaded files.
- The application doesn't send any identifying information to the server.

## Server Configuration

### File List Format

The application expects the file list at `aptlantis.net/files.txt` to be a plain text file with one file per line. The format supports two variations:

1. **Simple format**: Just the filename or path
   ```
   file1.txt
   documents/report.pdf
   image.jpg
   ```

2. **Extended format**: Filename and size separated by a pipe character (|)
   ```
   file1.txt|1024
   documents/report.pdf|1048576
   image.jpg|512000
   ```

The size is specified in bytes and will be displayed in a human-readable format in the application.

### Base URL Configuration

The application uses `https://aptlantis.net/` as the base URL for downloading files. The file paths from the list are appended to this base URL.

## Distribution

For maximum security and ease of distribution:

1. Compile the application for all target platforms.
2. Rename the executable to something innocuous if necessary.
3. Distribute through secure channels.
4. Consider obfuscation techniques if necessary to avoid detection.

## License

This project is licensed under the MIT License - see the LICENSE file for details.
