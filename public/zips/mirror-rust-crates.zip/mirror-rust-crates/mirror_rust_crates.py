#!/usr/bin/env python3
# =========================================================
# Script Name: mirror_rust_crates.py
# Description: Mirror Rust crates from crates.io to /mnt/aptlantis/mirror/Rust/
# Author: APTlantis Team
# Creation Date: 2023-11-15
# 
# Dependencies:
# - git
# - requests
# - tqdm
# 
# Usage:
#   python mirror_rust_crates.py [options]
# =========================================================

import os
import sys
import subprocess
import argparse
from pathlib import Path

def parse_arguments():
    """Parse command line arguments.

    Returns:
        argparse.Namespace: Parsed command line arguments
    """
    parser = argparse.ArgumentParser(description="Mirror Rust crates from crates.io")
    parser.add_argument("--index-dir", type=str, default="/mnt/aptlantis/mirror/Rust/crates.io-index",
                        help="Path to local crates.io index (default: /mnt/aptlantis/mirror/Rust/crates.io-index)")
    parser.add_argument("--output-dir", type=str, default="/mnt/aptlantis/mirror/Rust/crates",
                        help="Directory where .crate files will be saved (default: /mnt/aptlantis/mirror/Rust/crates)")
    parser.add_argument("--log-path", type=str, default="/mnt/aptlantis/mirror/Rust/crate-download-log.txt",
                        help="Path to log file (default: /mnt/aptlantis/mirror/Rust/crate-download-log.txt)")
    parser.add_argument("--threads", type=int, default=4,
                        help="Number of download threads (default: 4)")
    parser.add_argument("--rate-limit", type=float, default=0.5,
                        help="Minimum time between requests in seconds (default: 0.5)")
    parser.add_argument("--resume", action="store_true",
                        help="Resume from last run")
    parser.add_argument("--verify", action="store_true",
                        help="Verify downloaded crates")
    parser.add_argument("--skip-index-update", action="store_true",
                        help="Skip updating the crates.io index")
    return parser.parse_args()

def ensure_directory(path):
    """Ensure that a directory exists.

    Args:
        path: Path to the directory to create
    """
    Path(path).mkdir(parents=True, exist_ok=True)
    print(f"Ensured directory exists: {path}")

def clone_or_update_index(index_dir, skip_update=False):
    """Clone or update the crates.io index repository.

    Args:
        index_dir: Path to the crates.io index directory
        skip_update: Whether to skip updating the index if it already exists

    Returns:
        bool: True if successful, False otherwise
    """
    index_path = Path(index_dir)
    
    if index_path.exists() and (index_path / ".git").exists():
        print(f"Crates.io index already exists at {index_dir}")
        if skip_update:
            print("Skipping index update as requested")
            return True
        
        print("Updating crates.io index...")
        try:
            # Change to the index directory
            os.chdir(index_dir)
            # Pull the latest changes
            result = subprocess.run(["git", "pull"], check=True, capture_output=True, text=True)
            print(result.stdout)
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error updating crates.io index: {e}")
            print(f"Error output: {e.stderr}")
            return False
    else:
        print(f"Cloning crates.io index to {index_dir}...")
        try:
            # Create parent directory if it doesn't exist
            index_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Clone the repository
            result = subprocess.run(
                ["git", "clone", "https://github.com/rust-lang/crates.io-index.git", str(index_dir)],
                check=True,
                capture_output=True,
                text=True
            )
            print(result.stdout)
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error cloning crates.io index: {e}")
            print(f"Error output: {e.stderr}")
            return False

def run_mirror_crates(args):
    """Run the mirror_crates.py script with the given arguments.

    Args:
        args: Command line arguments

    Returns:
        bool: True if successful, False otherwise
    """
    # Get the directory of this script
    script_dir = Path(__file__).parent.absolute()
    mirror_crates_path = script_dir / "mirror_crates.py"
    
    if not mirror_crates_path.exists():
        print(f"Error: mirror_crates.py not found at {mirror_crates_path}")
        return False
    
    print(f"Running mirror_crates.py...")
    try:
        cmd = [
            sys.executable,
            str(mirror_crates_path),
            f"--index-dir={args.index_dir}",
            f"--output-dir={args.output_dir}",
            f"--log-path={args.log_path}",
            f"--threads={args.threads}",
            f"--rate-limit={args.rate_limit}"
        ]
        
        if args.resume:
            cmd.append("--resume")
        
        if args.verify:
            cmd.append("--verify")
        
        result = subprocess.run(cmd, check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error running mirror_crates.py: {e}")
        return False

def main():
    """Main function to mirror Rust crates from crates.io."""
    args = parse_arguments()
    
    # Ensure output directory exists
    ensure_directory(args.output_dir)
    
    # Clone or update the crates.io index
    if not args.skip_index_update:
        if not clone_or_update_index(args.index_dir, skip_update=args.skip_index_update):
            print("Failed to clone or update crates.io index. Exiting.")
            return 1
    
    # Run the mirror_crates.py script
    if not run_mirror_crates(args):
        print("Failed to run mirror_crates.py. Exiting.")
        return 1
    
    print("Rust crates mirroring completed successfully.")
    return 0

if __name__ == "__main__":
    sys.exit(main())