# Rust Crates Tools

This directory contains tools for mirroring, analyzing, and organizing Rust crates from crates.io.

## Tools Overview

1. **mirror_rust_crates.py** - Main script for mirroring Rust crates from crates.io
2. **mirror_crates.py** - Core downloading script used by mirror_rust_crates.py
3. **CrateAnalyzer.kt** - Kotlin application for analyzing the mirrored crates
4. **organize_crates.py** - Script for organizing crates from a flat directory into alphabetical subdirectories
5. **organize_metadata.py** - Script for organizing metadata files from crates.io-index to be alongside their crate files
6. **create_component_metadata.py** - Script for creating unified metadata files (component.json) for each major directory

## 1. Mirror Rust Crates (mirror_rust_crates.py)

This is the main script for mirroring Rust crates. It handles both cloning/updating the crates.io index repository and downloading the actual crate files.

### Features

- Automatically clones or updates the crates.io index repository
- Uses mirror_crates.py to download crate files
- Multi-threaded downloading for efficient mirroring
- Rate limiting to avoid overwhelming the crates.io server
- Resume capability for interrupted downloads
- Verification of downloaded crates
- Detailed logging of download progress and errors

### Usage

```bash
python mirror_rust_crates.py [options]
```

### Options

- `--index-dir`: Path to local crates.io index (default: "/mnt/aptlantis/mirror/Rust/crates.io-index")
- `--output-dir`: Directory where .crate files will be saved (default: "/mnt/aptlantis/mirror/Rust/crates")
- `--log-path`: Path to log file (default: "/mnt/aptlantis/mirror/Rust/crate-download-log.txt")
- `--threads`: Number of download threads (default: 4)
- `--rate-limit`: Minimum time between requests in seconds (default: 0.5)
- `--resume`: Resume from last run
- `--verify`: Verify downloaded crates
- `--skip-index-update`: Skip updating the crates.io index

For more details, see [mirror_rust_crates_README.md](mirror_rust_crates_README.md).

## 2. Mirror Crates (mirror_crates.py)

This is the core downloading script used by mirror_rust_crates.py. It handles the actual downloading of crate files.

### Features

- Multi-threaded downloading for efficient mirroring
- Rate limiting to avoid overwhelming the crates.io server
- Resume capability for interrupted downloads
- Verification of downloaded crates
- Detailed logging of download progress and errors

### Usage

```bash
python mirror_crates.py [options]
```

### Options

- `--index-dir`: Path to local crates.io index (default: "E:/crates.io-index")
- `--output-dir`: Directory where .crate files will be saved (default: "E:/crates-mirror")
- `--log-path`: Path to log file (default: "E:/crate-download-log.txt")
- `--threads`: Number of download threads (default: 4)
- `--rate-limit`: Minimum time between requests in seconds (default: 0.5)
- `--resume`: Resume from last run
- `--verify`: Verify downloaded crates

## 3. Crate Analyzer (CrateAnalyzer.kt)

This is a Kotlin application for analyzing the mirrored crates. It provides various statistics and insights about the crates.

### Features

- Count every crate and its versions
- Calculate average version depth per crate
- Extract crate names with the most frequent updates
- Detect orphaned, abandoned, or single-version crates
- Sort by largest crate size, metadata size, etc.
- Parse crates.io-index metadata and link it to local crates
- Track yanked crates and filter them out
- Analyze dependency relationships
- Identify crates with no dependencies
- Examine feature map coverage

### Usage

The easiest way to use the Crate Analyzer is with the provided batch script:

```bash
analyze_crates.bat [options]
```

Alternatively, you can compile and run the Kotlin code directly:

```bash
kotlinc CrateAnalyzer.kt -include-runtime -d CrateAnalyzer.jar
java -jar CrateAnalyzer.jar [options]
```

### Options

- `--mirror-dir <path>`: Directory containing the mirrored crates (default: E:\crates-mirror)
- `--index-dir <path>`: Directory containing the crates.io index (default: E:\crates.io-index)
- `--output-file <path>`: File to write the analysis results to (default: crate-analysis-[timestamp].txt)
- `--top-n <number>`: Number of top items to show in each category (default: 20)

For more details, see [CrateAnalyzer_README.md](CrateAnalyzer_README.md).

## 4. Organize Crates (organize_crates.py)

This script organizes Rust crates from a flat directory structure into a hierarchical directory structure with two levels of subdirectories, significantly reducing the number of files in each directory.

### Features

- Organizes files into a hierarchical directory structure:
  - First-level directories (A-Z, 0-9, OTHER) based on the first character
  - Second-level directories (AA-AD, AE-AH, etc.) based on the first two characters
- Intelligent grouping of second-level directories to balance file distribution
- Multi-threaded file moving for efficiency
- Dry-run mode for testing without actually moving files
- Comprehensive logging with counts for each directory level
- Progress bar to track file movement
- Error handling to catch and log any issues

### Usage

The easiest way to use the Organize Crates script is with the provided batch script:

```bash
organize_crates.bat [options]
```

Alternatively, you can run the Python script directly:

```bash
python organize_crates.py [options]
```

### Options

- `--source-dir <path>`: Directory containing the crate files (default: E:\crates-mirror)
- `--log-path <path>`: Path to log file (default: E:\crates-organize-log.txt)
- `--threads <number>`: Number of worker threads (default: 4)
- `--dry-run`: Run in dry-run mode (no files will be moved)

For more details, see [organize_crates_README.md](organize_crates_README.md).

## 5. Organize Metadata (organize_metadata.py)

This script organizes metadata files from the crates.io-index repository to be alongside their corresponding crate files in the mirror directory.

### Features

- Recursively scans the crates.io-index directory to find all metadata files
- For each metadata file, extracts the crate name and processes each version
- For each version, finds the corresponding crate file in the mirror directory
- Creates a metadata JSON file alongside the crate file
- Multi-threaded processing for efficiency
- Dry-run mode for testing without actually creating files
- Comprehensive logging with counts for each step
- Progress bar to track file processing

### Usage

The easiest way to use the Organize Metadata script is with the provided batch script:

```bash
organize_metadata.bat [options]
```

Alternatively, you can run the Python script directly:

```bash
python organize_metadata.py [options]
```

### Options

- `--index-dir <path>`: Directory containing the crates.io index (default: E:\crates.io-index)
- `--mirror-dir <path>`: Directory containing the mirrored crates (default: E:\crates-mirror)
- `--log-path <path>`: Path to log file (default: E:\metadata-organize-log.txt)
- `--threads <number>`: Number of worker threads (default: 4)
- `--dry-run`: Run in dry-run mode (no files will be created)

For more details, see [organize_metadata_README.md](organize_metadata_README.md).

## 6. Component Metadata Generator (create_component_metadata.py)

This script creates unified metadata files (meta.toml or component.json) for each major directory in the repository.

### Features

- Recursively scans the base directory to find all component directories (root, first-level, and second-level directories)
- For each directory, collects metadata including:
  - Component name (derived from directory name)
  - Primary programming language (detected from file extensions)
  - Purpose description
  - Last updated timestamp
  - Owner information
  - Component status
  - Entry point file
- Creates either meta.toml (default) or component.json files in each directory
- Automatically detects the primary programming language based on file extensions
- Identifies potential entry point files based on common naming patterns
- Multi-threaded processing for efficiency
- Dry-run mode for testing without actually creating files
- Comprehensive logging with counts for each step
- Progress bar to track directory processing
- Fallback implementation if the toml module is not available

### Usage

The easiest way to use the Component Metadata Generator is with the provided batch script:

```bash
create_component_metadata.bat [options]
```

Alternatively, you can run the Python script directly:

```bash
python create_component_metadata.py [options]
```

### Options

- `--base-dir <path>`: Base directory to process (default: E:\mnt\aptlantis\scripts)
- `--format <format>`: Format of metadata files (choices: json, toml; default: toml)
- `--log-path <path>`: Path to log file (default: E:\component-metadata-log.txt)
- `--threads <number>`: Number of worker threads (default: 4)
- `--dry-run`: Run in dry-run mode (no files will be created)

For more details, see [create_component_metadata_README.md](create_component_metadata_README.md).

## Requirements

- Python 3.6 or higher (for mirroring scripts)
- requests (Python package)
- tqdm (Python package)
- Kotlin compiler and JRE 8+ (for Crate Analyzer)
