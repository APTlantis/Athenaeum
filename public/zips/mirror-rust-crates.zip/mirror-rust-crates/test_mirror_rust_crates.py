#!/usr/bin/env python3
# =========================================================
# Script Name: test_mirror_rust_crates.py
# Description: Test the mirror_rust_crates.py script with a small subset of crates
# Author: APTlantis Team
# Creation Date: 2023-11-15
# 
# Dependencies:
# - Same as mirror_rust_crates.py
# 
# Usage:
#   python test_mirror_rust_crates.py
# =========================================================

import os
import sys
import tempfile
import shutil
import subprocess
from pathlib import Path

def run_test():
    """Run a test of the mirror_rust_crates.py script with a temporary directory."""
    script_dir = Path(__file__).parent.absolute()
    mirror_script = script_dir / "mirror_rust_crates.py"
    
    if not mirror_script.exists():
        print(f"Error: mirror_rust_crates.py not found at {mirror_script}")
        return False
    
    # Create temporary directories for testing
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        index_dir = temp_path / "crates.io-index"
        output_dir = temp_path / "crates"
        log_path = temp_path / "crate-download-log.txt"
        
        print(f"Testing with temporary directories:")
        print(f"  Index directory: {index_dir}")
        print(f"  Output directory: {output_dir}")
        print(f"  Log path: {log_path}")
        
        # Run the script with limited options for testing
        try:
            cmd = [
                sys.executable,
                str(mirror_script),
                f"--index-dir={index_dir}",
                f"--output-dir={output_dir}",
                f"--log-path={log_path}",
                "--threads=2",
                "--rate-limit=1.0"  # Slower rate limit for testing
            ]
            
            print("Running mirror_rust_crates.py with test parameters...")
            result = subprocess.run(cmd, check=True, capture_output=True, text=True)
            
            # Check if the index directory was created
            if not index_dir.exists():
                print("Test failed: Index directory was not created")
                return False
            
            # Check if the output directory was created
            if not output_dir.exists():
                print("Test failed: Output directory was not created")
                return False
            
            # Check if the log file was created
            if not log_path.exists():
                print("Test failed: Log file was not created")
                return False
            
            # Check if any crates were downloaded (this might take a while in a real test)
            crate_files = list(output_dir.glob("*.crate"))
            if not crate_files:
                print("Note: No crate files were downloaded during the test")
                print("This is expected if the test was interrupted early")
            else:
                print(f"Successfully downloaded {len(crate_files)} crate files")
            
            print("Test completed successfully!")
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"Test failed: Error running mirror_rust_crates.py: {e}")
            print(f"Error output: {e.stderr}")
            return False
        except Exception as e:
            print(f"Test failed: Unexpected error: {e}")
            return False

def main():
    """Main function to run the test."""
    print("Starting test of mirror_rust_crates.py...")
    success = run_test()
    
    if success:
        print("\nAll tests passed!")
        return 0
    else:
        print("\nTest failed!")
        return 1

if __name__ == "__main__":
    sys.exit(main())