# =========================================================
# Script Name: mirror_crates.py
# Description: Mirror Rust crates from crates.io with multi-threaded downloading
# Author: APTlantis Team
# Creation Date: 2025-05-20
# Last Modified: 2025-05-20
# 
# Dependencies:
# - requests
# - tqdm
# 
# Usage:
#   python mirror_crates.py [options]
# 
# Options:
#   --index-dir     Path to local crates.io index
#   --output-dir    Directory where .crate files will be saved
#   --log-path      Path to log file
#   --threads       Number of download threads
#   --rate-limit    Minimum time between requests in seconds
#   --resume        Resume from last run
#   --verify        Verify downloaded crates
# =========================================================

import os
import json
import time
import queue
import argparse
import requests
import threading
import concurrent.futures
from pathlib import Path
from datetime import datetime
from queue import Queue
from tqdm import tqdm

# === ARGUMENT PARSING ===
def parse_arguments():
    """Parse command line arguments.

    Returns:
        argparse.Namespace: Parsed command line arguments
    """
    parser = argparse.ArgumentParser(description="Mirror crates from crates.io")
    parser.add_argument("--index-dir", type=str, default="E:/crates.io-index",
                        help="Path to local crates.io index")
    parser.add_argument("--output-dir", type=str, default="E:/crates-mirror",
                        help="Directory where .crate files will be saved")
    parser.add_argument("--log-path", type=str, default="E:/crate-download-log.txt",
                        help="Path to log file")
    parser.add_argument("--threads", type=int, default=4,
                        help="Number of download threads")
    parser.add_argument("--rate-limit", type=float, default=0.5,
                        help="Minimum time between requests in seconds")
    parser.add_argument("--resume", action="store_true",
                        help="Resume from last run")
    parser.add_argument("--verify", action="store_true",
                        help="Verify downloaded crates")
    return parser.parse_args()

# === CONFIG ===
def load_config(index_dir):
    """Load configuration from config.json in the index directory.

    Args:
        index_dir: Path to the crates.io index directory

    Returns:
        dict: Configuration dictionary with 'dl' and 'api' keys
    """
    config_path = Path(index_dir) / "config.json"
    if config_path.exists():
        with open(config_path, "r") as f:
            return json.load(f)
    return {"dl": "https://static.crates.io/crates", "api": "https://crates.io"}

# === CRAWL FILES ===
def find_crates(index_dir):
    """Find all crate index files in the index directory.

    Args:
        index_dir: Path to the crates.io index directory

    Returns:
        list: List of paths to crate index files
    """
    crate_files = []
    for root, _, files in os.walk(index_dir):
        # Skip .git and other hidden directories
        if any(part.startswith('.') for part in Path(root).parts):
            continue

        for file in files:
            # Skip config.json and other non-index files
            if file == "config.json" or file.startswith('.'):
                continue

            full_path = os.path.join(root, file)
            crate_files.append(full_path)

    print(f"Found {len(crate_files)} crate index files.")
    return crate_files

# === DOWNLOAD .crate TAR FILE ===
def download_crate(crate_name, version, config, output_dir, headers, rate_limiter, verify=False):
    """Download a crate file from crates.io.

    Args:
        crate_name: Name of the crate
        version: Version of the crate
        config: Configuration dictionary with download URLs
        output_dir: Directory to save the crate file
        headers: HTTP headers for the request
        rate_limiter: Rate limiter to control request frequency
        verify: Whether to verify existing crate files

    Returns:
        str: Status message indicating the result of the download
    """
    # Use the direct download URL from config
    url = f"{config['dl']}/{crate_name}/{crate_name}-{version}.crate"
    out_path = Path(output_dir) / f"{crate_name}-{version}.crate"

    if out_path.exists():
        if verify:
            # Simple size verification - could be enhanced with checksum verification
            if out_path.stat().st_size > 0:
                return "verified"
            else:
                # File exists but is empty or corrupted - remove it and try again
                try:
                    out_path.unlink()
                except Exception as e:
                    return f"error (failed to remove corrupted file: {str(e)})"
        else:
            return "skipped"

    # Apply rate limiting
    with rate_limiter:
        try:
            r = requests.get(url, stream=True, headers=headers, timeout=30)
            if r.status_code == 200:
                with open(out_path, "wb") as f:
                    for chunk in r.iter_content(1024 * 256):
                        f.write(chunk)
                return "downloaded"
            else:
                # Fallback to API endpoint if direct download fails
                api_url = f"{config['api']}/api/v1/crates/{crate_name}/{version}/download"
                r = requests.get(api_url, stream=True, headers=headers, timeout=30)
                if r.status_code == 200:
                    with open(out_path, "wb") as f:
                        for chunk in r.iter_content(1024 * 256):
                            f.write(chunk)
                    return "downloaded (api fallback)"
                else:
                    return f"failed ({r.status_code})"
        except Exception as e:
            return f"error ({str(e)})"

# === RATE LIMITER ===
class RateLimiter:
    """Rate limiter to control the frequency of requests.

    This class implements a context manager that can be used with the 'with' statement
    to limit the rate of requests to a server.
    """
    def __init__(self, rate_limit):
        """Initialize the rate limiter.

        Args:
            rate_limit: Minimum time between requests in seconds
        """
        self.rate_limit = rate_limit
        self.last_request = 0
        self.lock = threading.Lock()

    def __enter__(self):
        """Enter the context manager, applying rate limiting if needed."""
        with self.lock:
            current_time = time.time()
            time_since_last = current_time - self.last_request
            if time_since_last < self.rate_limit:
                time.sleep(self.rate_limit - time_since_last)
            self.last_request = time.time()

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit the context manager."""
        pass

# === PROCESS CRATE INDEX FILE ===
def process_crate_file(file_path, download_queue, log_queue, resume_data=None):
    """Process a crate index file and add crates to the download queue.

    Args:
        file_path: Path to the crate index file
        download_queue: Queue to add crates to
        log_queue: Queue for logging messages
        resume_data: Dictionary of already processed crates to skip
    """
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                try:
                    crate = json.loads(line)
                    name = crate["name"]
                    version = crate["vers"]

                    # Skip if already processed in a previous run
                    if resume_data and name in resume_data and resume_data[name] >= version:
                        continue

                    download_queue.put((name, version))
                except Exception as e:
                    log_queue.put(f"ERROR in {file_path}: {str(e)}")
    except Exception as outer:
        log_queue.put(f"FILE READ FAIL: {file_path}: {str(outer)}")

# === DOWNLOAD WORKER ===
def download_worker(download_queue, log_queue, config, output_dir, headers, rate_limiter, verify, progress):
    """Worker thread that downloads crates from the queue.

    Args:
        download_queue: Queue containing crates to download
        log_queue: Queue for logging messages
        config: Configuration dictionary with download URLs
        output_dir: Directory to save crate files
        headers: HTTP headers for requests
        rate_limiter: Rate limiter to control request frequency
        verify: Whether to verify existing crate files
        progress: Progress bar to update
    """
    while True:
        try:
            name, version = download_queue.get(block=False)
            result = download_crate(name, version, config, output_dir, headers, rate_limiter, verify)
            log_queue.put(f"{name} {version}: {result}")
            progress.update(1)
        except queue.Empty:
            break
        except Exception as e:
            log_queue.put(f"WORKER ERROR: {str(e)}")
        finally:
            download_queue.task_done()

# === LOGGER WORKER ===
def logger_worker(log_queue, log_path, resume_data, download_queue):
    """Worker thread that handles logging and updating resume data.

    Args:
        log_queue: Queue containing log messages
        log_path: Path to the log file
        resume_data: Dictionary to store resume data
        download_queue: Queue containing crates to download, used to check if work is done
    """
    with open(log_path, "a", encoding="utf-8") as log:
        log.write(f"\n--- Session started at {datetime.now()} ---\n")
        while True:
            try:
                message = log_queue.get(block=True, timeout=1)
                log.write(f"{message}\n")
                log.flush()

                # Update resume data if it's a successful download
                if ": downloaded" in message or ": verified" in message or ": skipped" in message:
                    parts = message.split(":", 1)[0].strip().split()
                    if len(parts) >= 2:
                        name, version = parts
                        resume_data[name] = version

                log_queue.task_done()
            except queue.Empty:
                # Check if both queues are empty and all tasks are done
                if log_queue.empty() and download_queue.empty():
                    break

# === MAIN FUNCTION ===
def main():
    """Main function to mirror crates from crates.io.

    This function parses command line arguments, sets up the environment,
    and starts the download process with multiple threads.
    """
    args = parse_arguments()

    # Setup paths
    index_dir = Path(args.index_dir)
    output_dir = Path(args.output_dir)
    log_path = Path(args.log_path)
    resume_path = output_dir / ".resume.json"

    # Create output directory
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load config
    config = load_config(index_dir)

    # Setup headers
    headers = {"User-Agent": "APTlantis Crate Mirror Bot v2.0"}

    # Load resume data if requested
    resume_data = {}
    if args.resume and resume_path.exists():
        try:
            with open(resume_path, "r") as f:
                resume_data = json.load(f)
            print(f"Resuming from previous run with {len(resume_data)} crates already processed.")
        except Exception as e:
            print(f"Error loading resume data: {e}")

    # Create queues
    download_queue = Queue()
    log_queue = Queue()

    # Create rate limiter
    rate_limiter = RateLimiter(args.rate_limit)

    # Find all crate index files
    crate_files = find_crates(index_dir)

    # Process crate files and populate download queue
    print("Processing crate index files...")
    total_crates = 0
    for file_path in tqdm(crate_files, desc="Reading index files"):
        # Pass resume_data to process_crate_file to skip already processed crates
        process_crate_file(file_path, download_queue, log_queue, resume_data if args.resume else None)
        total_crates += 1

    # Get queue size for progress bar
    queue_size = download_queue.qsize()
    print(f"Found {queue_size} crates to process.")

    # Create progress bar
    progress = tqdm(total=queue_size, desc="Downloading crates")

    # Start download workers
    print(f"Starting {args.threads} download threads...")
    threads = []
    for _ in range(args.threads):
        thread = threading.Thread(
            target=download_worker,
            args=(download_queue, log_queue, config, output_dir, headers, rate_limiter, args.verify, progress)
        )
        thread.daemon = True
        thread.start()
        threads.append(thread)

    # Start logger thread
    logger_thread = threading.Thread(
        target=logger_worker,
        args=(log_queue, log_path, resume_data, download_queue)
    )
    logger_thread.daemon = True
    logger_thread.start()

    # Wait for all downloads to complete
    download_queue.join()
    log_queue.join()

    # Wait for all threads to finish
    for thread in threads:
        thread.join()
    logger_thread.join()

    # Save resume data
    with open(resume_path, "w") as f:
        json.dump(resume_data, f)

    print(f"Finished. Total processed: {queue_size}")

if __name__ == "__main__":
    main()
