# Rust Crates Mirror Script

This script automates the process of mirroring Rust crates from crates.io to a local directory. It handles both cloning/updating the crates.io index repository and downloading the actual crate files.

## Features

- Automatically clones or updates the crates.io index repository
- Uses the existing mirror_crates.py script to download crate files
- Multi-threaded downloading for efficient mirroring
- Rate limiting to avoid overwhelming the crates.io server
- Resume capability for interrupted downloads
- Verification of downloaded crates
- Detailed logging of download progress and errors

## Prerequisites

- Python 3.6 or higher
- Git
- requests (Python package)
- tqdm (Python package)

## Installation

1. Ensure you have Python 3.6+ and Git installed
2. Install required Python packages:
   ```bash
   pip install requests tqdm
   ```

## Usage

```bash
python mirror_rust_crates.py [options]
```

## Options

- `--index-dir`: Path to local crates.io index (default: "/mnt/aptlantis/mirror/Rust/crates.io-index")
- `--output-dir`: Directory where .crate files will be saved (default: "/mnt/aptlantis/mirror/Rust/crates")
- `--log-path`: Path to log file (default: "/mnt/aptlantis/mirror/Rust/crate-download-log.txt")
- `--threads`: Number of download threads (default: 4)
- `--rate-limit`: Minimum time between requests in seconds (default: 0.5)
- `--resume`: Resume from last run
- `--verify`: Verify downloaded crates
- `--skip-index-update`: Skip updating the crates.io index

## Examples

### Basic Usage

```bash
python mirror_rust_crates.py
```

This will:
1. Clone the crates.io index to "/mnt/aptlantis/mirror/Rust/crates.io-index" (or update it if it already exists)
2. Download all crates to "/mnt/aptlantis/mirror/Rust/crates"

### Custom Directories

```bash
python mirror_rust_crates.py --index-dir="/path/to/index" --output-dir="/path/to/mirror"
```

### Faster Downloading

```bash
python mirror_rust_crates.py --threads=8 --rate-limit=0.2
```

This increases the number of download threads to 8 and reduces the time between requests.

### Resume Interrupted Download

```bash
python mirror_rust_crates.py --resume
```

This will continue from where the previous run left off.

### Skip Index Update

```bash
python mirror_rust_crates.py --skip-index-update
```

This will skip updating the crates.io index and only download crates.

## How It Works

1. The script first ensures that the output directory exists
2. It then clones the crates.io index repository if it doesn't exist, or updates it if it does
3. Finally, it runs the mirror_crates.py script to download the actual crate files

The crates.io index is a Git repository containing metadata about all crates on crates.io. This metadata is used to determine which crates to download.

## Troubleshooting

- If you encounter network issues, try increasing the `--rate-limit` value
- If the script fails, you can use the `--resume` option to continue from where it left off
- Check the log file for detailed information about any errors