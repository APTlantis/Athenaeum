# Image to WebP Converter

This script converts images in a directory to WebP format while preserving the original files.

## Requirements

- Python 3.6 or higher
- Pillow library

## Installation

1. Make sure you have Python installed on your system. You can download it from [python.org](https://www.python.org/downloads/).

2. Install the required Pillow library:

```bash
pip install Pillow
```

## Usage

### Basic Usage

Run the script with default settings:

```bash
python convert_to_webp.py
```

By default, the script will:
- Process all images in `E:\hetzner website\v6\public\logos`
- Use a WebP quality setting of 80 (on a scale of 0-100)

### Custom Options

You can customize the directory and quality settings:

```bash
python convert_to_webp.py --dir "path\to\your\images" --quality 90
```

### Command-line Arguments

- `--dir`: Directory containing images to convert (default: `E:\hetzner website\v6\public\logos`)
- `--quality`: WebP quality setting from 0 to 100 (default: 80)

## Supported Image Formats

The script can convert the following image formats to WebP:
- JPEG (.jpg, .jpeg)
- PNG (.png)
- GIF (.gif)
- BMP (.bmp)
- TIFF (.tiff)

## Notes

- The script preserves the original images and creates WebP versions alongside them
- Images that are already in WebP format will be skipped
- Transparency in PNG images is preserved in the WebP output