# =========================================================
# Script Name: convert_to_webp.py
# Description: Convert images to WebP format with quality control
# Author: APTlantis Team
# Creation Date: 2025-05-17
# Last Modified: 2025-05-21
# 
# Dependencies:
# - Python 3.x
# - Pillow (PIL)
# 
# Usage:
#   python convert_to_webp.py --dir [directory] --quality [0-100]
# 
# Options:
#   --dir      Directory containing images to convert
#   --quality  WebP quality (0-100)
# =========================================================

import os
import argparse
from PIL import Image
import sys

def convert_to_webp(input_path, quality=80):
    """
    Convert an image to WebP format

    Args:
        input_path (str): Path to the input image
        quality (int): WebP quality (0-100)

    Returns:
        bool: True if conversion was successful, False otherwise
    """
    try:
        # Get the file extension
        file_name, file_ext = os.path.splitext(input_path)
        output_path = f"{file_name}.webp"

        # Skip if the file is already a WebP
        if file_ext.lower() == '.webp':
            print(f"Skipping {input_path} - already in WebP format")
            return False

        # Open the image
        with Image.open(input_path) as img:
            # Convert to RGB if the image is in RGBA mode (for PNG with transparency)
            if img.mode == 'RGBA':
                # WebP supports transparency, so we can keep the alpha channel
                img.save(output_path, 'WEBP', quality=quality, lossless=False)
            else:
                # For other formats, convert to RGB if needed
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                img.save(output_path, 'WEBP', quality=quality, lossless=False)

        print(f"Converted: {input_path} -> {output_path}")
        return True
    except Exception as e:
        print(f"Error converting {input_path}: {e}")
        return False

def process_directory(directory_path, quality=80):
    """
    Process all images in a directory

    Args:
        directory_path (str): Path to the directory containing images
        quality (int): WebP quality (0-100)

    Returns:
        int: Number of images converted
    """
    # Check if directory exists
    if not os.path.isdir(directory_path):
        print(f"Error: {directory_path} is not a valid directory")
        return 0

    # Supported image formats
    supported_formats = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff']

    # Counter for converted images
    converted_count = 0

    # Walk through the directory
    for root, _, files in os.walk(directory_path):
        for file in files:
            file_path = os.path.join(root, file)
            file_ext = os.path.splitext(file)[1].lower()

            # Check if the file is a supported image format
            if file_ext in supported_formats:
                if convert_to_webp(file_path, quality):
                    converted_count += 1

    return converted_count

def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Convert images to WebP format')
    parser.add_argument('--dir', type=str, default=r'E:\hetzner website\v6\public\logos',
                        help='Directory containing images to convert')
    parser.add_argument('--quality', type=int, default=80,
                        help='WebP quality (0-100)')
    args = parser.parse_args()

    # Process the directory
    print(f"Processing directory: {args.dir}")
    converted_count = process_directory(args.dir, args.quality)
    print(f"Conversion complete. Converted {converted_count} images to WebP format.")

if __name__ == "__main__":
    main()
