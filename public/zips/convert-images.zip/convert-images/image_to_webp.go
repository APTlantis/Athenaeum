// =========================================================
// Script Name: image_to_webp.go
// Description: Go implementation for converting images to WebP format
// Author: APTlantis Team
// Creation Date: 2025-05-17
// Last Modified: 2025-05-21
// 
// Dependencies:
// - github.com/chai2010/webp
// 
// Usage:
//   go run image_to_webp.go --dir [directory] --quality [0-100]
// 
// Options:
//   --dir      Directory containing images to convert
//   --quality  WebP quality (0-100)
// =========================================================

package main

import (
	"flag"
	"fmt"
	"image"
	"image/jpeg"
	"image/png"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"strings"

	"github.com/chai2010/webp"
)

func main() {
	// Define command-line flags
	dirPath := flag.String("dir", "E:\\hetzner website\\v6\\public\\logos", "Directory containing images to convert")
	quality := flag.Float64("quality", 80, "WebP quality (0-100)")
	flag.Parse()

	// Validate directory path
	info, err := os.Stat(*dirPath)
	if err != nil {
		log.Fatalf("Error accessing directory: %v", err)
	}
	if !info.IsDir() {
		log.Fatalf("%s is not a directory", *dirPath)
	}

	// Process all files in the directory
	count := 0
	err = filepath.WalkDir(*dirPath, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}

		// Skip directories and non-image files
		if d.IsDir() || !isImageFile(path) || isWebPFile(path) {
			return nil
		}

		// Convert the image to WebP
		err = convertToWebP(path, *quality)
		if err != nil {
			log.Printf("Error converting %s: %v", path, err)
			return nil
		}

		count++
		fmt.Printf("Converted: %s\n", path)
		return nil
	})

	if err != nil {
		log.Fatalf("Error walking directory: %v", err)
	}

	fmt.Printf("Conversion complete. Converted %d images to WebP format.\n", count)
}

// isImageFile checks if the file has an image extension
func isImageFile(path string) bool {
	ext := strings.ToLower(filepath.Ext(path))
	return ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".gif"
}

// isWebPFile checks if the file is already a WebP image
func isWebPFile(path string) bool {
	ext := strings.ToLower(filepath.Ext(path))
	return ext == ".webp"
}

// convertToWebP converts an image file to WebP format
func convertToWebP(path string, quality float64) error {
	// Open the source image
	file, err := os.Open(path)
	if err != nil {
		return fmt.Errorf("failed to open source image: %w", err)
	}
	defer file.Close()

	// Decode the image based on its format
	var img image.Image
	ext := strings.ToLower(filepath.Ext(path))

	switch ext {
	case ".png":
		img, err = png.Decode(file)
	case ".jpg", ".jpeg":
		img, err = jpeg.Decode(file)
	default:
		// For other formats, try to use the generic image decoder
		img, _, err = image.Decode(file)
	}

	if err != nil {
		return fmt.Errorf("failed to decode image: %w", err)
	}

	// Create the output WebP file
	webpPath := strings.TrimSuffix(path, ext) + ".webp"
	outFile, err := os.Create(webpPath)
	if err != nil {
		return fmt.Errorf("failed to create output file: %w", err)
	}
	defer outFile.Close()

	// Encode as WebP
	options := &webp.Options{
		Lossless: false,
		Quality:  quality,
	}
	if err := webp.Encode(outFile, img, options); err != nil {
		return fmt.Errorf("failed to encode as WebP: %w", err)
	}

	return nil
}
